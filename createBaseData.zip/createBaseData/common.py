root_url="http://perftestoffline.netease.com"
username="perftest"
password="dc483e80a7a0bd9ef71d8cf973673924"
corpid="63001"
appkey='78f3b883f14746b747656ef1b48a25f3'

formTypeHeaders = {
            'Content-Type': "application/x-www-form-urlencoded;charset=utf-8",
            'user-agent': "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36",
            'accept': "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3"
        }