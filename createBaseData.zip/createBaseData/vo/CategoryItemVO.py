class CategoryItemVO(object):
    def __init__(self, id, list, time):
        self.list = list
        self.id = id
        self.time = time